// server.js
const express = require('express');
const { insertUser, getUsers } = require('./crud'); // Import the function
const cors = require('cors');

const app = express();

// Allow requests from any origin
app.use(cors());

app.get('/', (req, res) => {
  res.send('Hello, World!');
});

// New route for getting language courses
app.post('/adduser', async (req, res) => {
  try {
    const userData = req.body;
    const result = await insertUser(userData);
    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});

app.get('/users', async (req, res) => {
    try {
      const courses = await getUsers();
      //console.log(courses)
      res.json(courses); // Send the courses as JSON
    } catch (error) {
      console.error(error);
      res.status(500).send('Server error');
    }
  });

const PORT = process.env.PORT || 3500;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));
