import React, { useState, useEffect } from 'react';
import './usersList.css'; // Make sure to create a UsersList.css file in the same directory

function UsersList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:3500/users'); // Replace with your actual API endpoint
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  };

  const addUser = async () => {
    // Implement adding user logic here 
    try {
      let reqBody = {

      };
      const response = await fetch('http://localhost:3500/adduser', reqBody); // Replace with your actual API endpoint
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  };

  const deleteUser = async (userId) => {
    // Implement deleting user logic here
  };

  const updateUser = async (user) => {
    // Implement updating user logic here
  };

  return (
    <div className="users-list">
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.email}</td>
              <td>
                <button onClick={() => deleteUser(user.id)}>Delete</button>
                <button onClick={() => updateUser(user)}>Update</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="actions">
        <button onClick={fetchUsers}>Fetch Users</button>
        <button onClick={addUser}>Register New User</button>
      </div>
    </div>
  );
}

export default UsersList;
