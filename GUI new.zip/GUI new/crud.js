// crud.js
const { sql, config } = require('./db');

async function insertUser() {
  try {
    await sql.connect(config);
    const result = await sql.query`INSERT INTO userProfile (firstName, lastName, email, dateOfBirth, gender, isActive, totalRewardPoints, subscriptionStatus)
    VALUES 
    ('Alex', 'Jones', 'alex123@llp.com', '1960-05-15', 'F', 'Yes', 600, 'Premium')`;
    console.log(result);
    return result.recordset; // Return the result set to the caller
  } catch (err) {
    console.error('SQL error', err);
  }
}

async function getUsers() {
    try {
      await sql.connect(config);
      const result = await sql.query`SELECT * FROM userProfile`;
      console.log(result);
      return result.recordset; // Return the result set to the caller
    } catch (err) {
      console.error('SQL error', err);
    }
  }

// Export the function for external use
module.exports = {
    insertUser, getUsers
};
