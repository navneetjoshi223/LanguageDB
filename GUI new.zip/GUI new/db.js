// db.js
const sql = require('mssql');

const config = {
  user: "sa",
  password: "Noburules95$",
  database: "LanguageLearningPlatform",
  server: "localhost",
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  },
  options: {
    encrypt: true, // for azure
    trustServerCertificate: true // change to true for local dev / self-signed certs
  }
};

// Export the connection pool
module.exports = { sql, config };
